
.mode tabs
.out words.tab
select * from words;
.out info.tab
select * from info;

