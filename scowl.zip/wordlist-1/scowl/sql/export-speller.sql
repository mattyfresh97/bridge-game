
.mode tabs
.out speller_words.tab
select * from speller_words;
.out post.tab
select * from post;
.out speller_cross.tab
select * from speller_cross;
.out dict_info.tab
select * from dict_info;

