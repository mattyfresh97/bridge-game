---
layout: readme-text
title: Hunspell English Dictionaries
file: hunspell-readme
---
