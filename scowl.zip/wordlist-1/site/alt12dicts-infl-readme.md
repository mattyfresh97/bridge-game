---
layout: readme-text
title: "Unofficial Alternate 12Dicts package: 2of12id"
file: alt12dicts-infl-readme
---
