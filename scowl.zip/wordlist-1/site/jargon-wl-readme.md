---
layout: readme-text
title: Unofficial Jargon File Word Lists
file: jargon-wl-readme
---
