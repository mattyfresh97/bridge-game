---
layout: readme-text
title: Part Of Speech Database
file: pos-readme
---
