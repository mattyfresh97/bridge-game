---
layout: readme-text
title: Automatically Generated Inflection Database (AGID)
file: agid-readme
---
