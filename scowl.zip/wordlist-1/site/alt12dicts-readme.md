---
layout: readme-text
title: Unofficial Alternate 12Dicts package
file: alt12dicts-readme
---
